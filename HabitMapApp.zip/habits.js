document.getElementById("habitForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const habits = [];
  document.querySelectorAll('input[name="habit"]:checked').forEach(el => habits.push(el.value));
  localStorage.setItem("myHabits", JSON.stringify(habits));
  document.getElementById("savedMsg").textContent = "✅ تم حفظ عاداتك!";
});